<?php

namespace EasingSlider\Foundation\Admin\Assets;

use EasingSlider\Foundation\Assets\Assets as BaseAssets;

/**
 * Exit if accessed directly
 */
if ( ! defined('ABSPATH')) {
	exit;
}

abstract class Assets extends BaseAssets
{
	//
}
