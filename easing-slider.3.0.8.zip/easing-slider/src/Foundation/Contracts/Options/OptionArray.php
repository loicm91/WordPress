<?php

namespace EasingSlider\Foundation\Contracts\Options;

use ArrayAccess;

/**
 * Exit if accessed directly
 */
if ( ! defined('ABSPATH')) {
	exit;
}

interface OptionArray extends ArrayAccess
{
	//
}
