<?php

namespace EasingSlider\Foundation\Contracts;

/**
 * Exit if accessed directly
 */
if ( ! defined('ABSPATH')) {
	exit;
}

interface Plugin
{
	//
}
