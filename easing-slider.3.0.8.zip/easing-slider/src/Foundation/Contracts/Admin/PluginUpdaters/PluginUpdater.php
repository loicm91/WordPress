<?php

namespace EasingSlider\Foundation\Contracts\Admin\PluginUpdaters;

/**
 * Exit if accessed directly
 */
if ( ! defined('ABSPATH')) {
	exit;
}

interface PluginUpdater
{
	//
}
