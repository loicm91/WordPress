<?php

namespace EasingSlider\Foundation\Contracts\Admin\Assets;

use EasingSlider\Foundation\Contracts\Assets\Assets as BaseAssets;

/**
 * Exit if accessed directly
 */
if ( ! defined('ABSPATH')) {
	exit;
}

interface Assets extends BaseAssets
{
	//
}
