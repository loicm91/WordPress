<?php

namespace EasingSlider\Foundation\Contracts\Admin\Actions;

/**
 * Exit if accessed directly
 */
if ( ! defined('ABSPATH')) {
	exit;
}

interface Actions
{
	//
}
