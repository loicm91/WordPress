<?php

namespace EasingSlider\Foundation\Contracts\Admin\Menus;

/**
 * Exit if accessed directly
 */
if ( ! defined('ABSPATH')) {
	exit;
}

interface Menu
{
	//
}
