<?php

namespace EasingSlider\Foundation\Contracts\Admin;

/**
 * Exit if accessed directly
 */
if ( ! defined('ABSPATH')) {
	exit;
}

interface Admin
{
	//
}
