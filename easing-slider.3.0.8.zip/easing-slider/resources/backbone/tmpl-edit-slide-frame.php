<script type="text/html" id="tmpl-easingslider-edit-slide-frame">
	<div class="edit-media-header">
		<button class="left dashicons"><span class="screen-reader-text"><?php _e('Edit previous media item', 'easingslider'); ?></span></button>
		<button class="right dashicons"><span class="screen-reader-text"><?php _e('Edit next media item', 'easingslider'); ?></span></button>
	</div>
	<div class="media-frame-title"></div>
	<div class="media-frame-content"></div>
	<div class="media-frame-toolbar"></div>
</script>
